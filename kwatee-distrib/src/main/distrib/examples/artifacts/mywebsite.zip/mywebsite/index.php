<?php
header("Pragma: no-cache");
header("Cache: no-cache");
?>
<img src="logo.gif" style="float:left;padding-right:5px"/>
Customer: %{CUSTOMER_NAME}<br/>
Hello world!<br/>